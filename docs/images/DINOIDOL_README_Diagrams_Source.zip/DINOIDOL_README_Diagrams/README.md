# DINOIDOL architecture diagrams

Editable diagrams for a GitHub README, with SVG and 2× PNG exports in light and dark themes. The main figure remakes the supplied DINOIDOL architecture; the companion figure remakes the DINOIDOL / CP-SIS comparison.

## Architecture

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="assets/dinoidol_architecture_dark.svg">
  <img src="assets/dinoidol_architecture_light.svg" alt="DINOIDOL: feature encoding, query initialization, instance prediction and IDOL temporal association" width="100%">
</picture>

This is a **conceptual integration based on the supplied images**, not a verified map of a particular repository. DINO-style query initialization, MaskDINO-style masks and IDOL-style temporal association are shown together. Exact feature scales, layer counts, denoising options and query initialization depend on the implementation and configuration.

1. **Encode each frame.** A backbone produces multi-scale features. Feature preparation adds position / level information, and the encoder produces contextual visual memory. The spatial branch includes the backbone / encoder feature fusion used for mask embeddings.
2. **Initialize and refine queries.** Top-K encoder proposals provide initial reference boxes. The illustrated DINO-style setting uses learned content queries. The decoder reads the encoder memory through cross-attention. Noisy ground-truth queries belong to the auxiliary denoising training branch.
3. **Predict instances.** Refined queries feed the class / box, mask and Re-ID heads. Mask prediction combines query mask embeddings with a high-resolution pixel embedding map. Re-ID vectors support identity matching across frames.
4. **Associate across time.** Per-frame predictions are packaged together and matched against track history. IDOL-style online association assigns persistent identities and updates track memory.

The joining line under the heads means **pack predictions from the same instance queries**, not sum their tensors. The orange dashed branch is training-only. The feature encoder is an aggregate block: it does not imply every operation shown in its caption is repeated N times. The diagram omits loss functions and intermediate supervision for readability.

## Complementary roles

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="assets/dinoidol_cpsis_comparison_dark.svg">
  <img src="assets/dinoidol_cpsis_comparison_light.svg" alt="DINOIDOL preserves temporal identity while CP-SIS separates instrument classes; integration remains a future direction" width="100%">
</picture>

The CP-SIS column summarizes the user-supplied comparison: proposal-defined visual features, DINOv2 adaptation, learnable class prototypes and class-aware masks. A prototype classifier combined with IDOL tracking remains **future work / unimplemented**, matching the supplied schematic. DINO (the DETR detector) / MaskDINO and DINOv2 (the visual feature backbone) are distinct model families.

## Use in an existing repository

Copy `assets/` into your repository and paste either `<picture>` block above into your README. Paths are relative to a README at the repository root. For a minimal embed:

```markdown
![DINOIDOL architecture](assets/dinoidol_architecture_light.svg)
```

Use the PNG with the same basename when an application cannot render SVG. SVGs contain editable text and shapes, an accessible title and description, explicit backgrounds, and no external assets or scripts.

## Diagram source code

| File | Purpose |
| --- | --- |
| [src/generate_diagrams.py](src/generate_diagrams.py) | Exact source for the styled SVG / PNG figures; wording, coordinates and theme palettes are editable. |
| [src/dinoidol_architecture.mmd](src/dinoidol_architecture.mmd) | Editable Mermaid representation of the architecture, including explicit track-memory feedback. |
| [src/dinoidol_cpsis_comparison.mmd](src/dinoidol_cpsis_comparison.mmd) | Editable Mermaid representation of the comparison. |
| [MERMAID.md](MERMAID.md) | Both Mermaid graphs in GitHub-renderable fenced blocks. |

Generate the SVGs with Python 3.9+; no Python packages are required:

```bash
python3 src/generate_diagrams.py
```

For 2× PNG exports, install Inkscape and run:

```bash
python3 src/generate_diagrams.py --png
```

To generate a single theme or choose a destination:

```bash
python3 src/generate_diagrams.py --theme dark --out ./my-diagrams
```

## Technical references and model source

These links ground the architectural conventions. They do not establish that the user's project implements every depicted component. No model implementation is included in this diagram package.

| Component | Primary reference / upstream code |
| --- | --- |
| DINO: mixed query selection and contrastive denoising | [Paper](https://arxiv.org/abs/2203.03605), [official repository](https://github.com/IDEA-Research/DINO), [transformer source](https://github.com/IDEA-Research/DINO/blob/main/models/dino/deformable_transformer.py) |
| MaskDINO: feature fusion, pixel embeddings and mask heads | [Paper](https://arxiv.org/abs/2206.02777), [official repository and component description](https://github.com/IDEA-Research/MaskDINO), [decoder source](https://github.com/IDEA-Research/MaskDINO/blob/main/maskdino/modeling/transformer_decoder/maskdino_decoder.py) |
| IDOL: instance embeddings and online history-based association | [Paper](https://arxiv.org/abs/2207.10661), [official code linked by the paper](https://github.com/wjf5203/VNext) |

Sources checked on 19 November 2026. The CP-SIS comparison is based on the supplied diagram, not a code audit. Denoising details differ between implementations; the CDN box preserves the DINO-style training branch from the supplied architecture.
