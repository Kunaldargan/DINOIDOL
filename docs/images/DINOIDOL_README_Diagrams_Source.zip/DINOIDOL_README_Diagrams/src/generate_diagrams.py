#!/usr/bin/env python3
"""Generate editable, self-contained SVG diagrams for a GitHub README.

Python standard library only. Use --png to render 2x PNGs with Inkscape.
All geometry, wording, and theme colors are defined below; no image model,
external assets, JavaScript, network access, or embedded raster is used.
"""
from __future__ import annotations

import argparse
from html import escape
from pathlib import Path
import shutil
import subprocess


THEMES = {
    "light": dict(bg="#f7f9fc", panel="#ffffff", text="#17243b", muted="#53647c",
                  border="#dce4ef", blue="#2563eb", blue_fill="#edf4ff",
                  teal="#087f77", teal_fill="#e9f8f4", amber="#a66300",
                  amber_fill="#fff6df", pink="#ab387d", pink_fill="#fff0f7"),
    "dark": dict(bg="#0d1424", panel="#141f33", text="#f0f5ff", muted="#b6c4da",
                 border="#32435e", blue="#8ab4ff", blue_fill="#1c3153",
                 teal="#73dfcc", teal_fill="#123a3b", amber="#ffd080",
                 amber_fill="#3b2e19", pink="#f5a3d1", pink_fill="#3a233d"),
}


class SVG:
    """Small deterministic SVG writer; every visible text element has an ID."""

    def __init__(self, width, height, theme, title, description):
        self.w, self.h, self.c = width, height, THEMES[theme]
        self.parts, self.seq, self.text_boxes = [], 0, []
        self.parts.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
                          f'viewBox="0 0 {width} {height}" role="img" aria-labelledby="title desc">')
        self.parts.append(f'<title id="title">{escape(title)}</title><desc id="desc">{escape(description)}</desc>')
        self.parts.append('<defs>')
        for color in ("blue", "teal", "amber", "pink", "muted"):
            self.parts.append(f'<marker id="arrow-{color}" viewBox="0 0 10 10" refX="9" refY="5" '
                              f'markerWidth="9" markerHeight="9" markerUnits="userSpaceOnUse" orient="auto-start-reverse">'
                              f'<path d="M 0 0 L 10 5 L 0 10 z" fill="{self.c[color]}"/></marker>')
        self.parts.append('</defs>')
        self.rect(0, 0, width, height, self.c["bg"], radius=0)

    def rect(self, x, y, w, h, fill, stroke=None, radius=16, dashed=False):
        dash = ' stroke-dasharray="8 6"' if dashed else ''
        self.parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{radius}" '
                          f'fill="{fill}" stroke="{stroke or fill}" stroke-width="1.6"{dash}/>')

    def text(self, x, y, value, size=22, weight=400, color="text", anchor="start", bounds=None):
        self.seq += 1
        ident = f'text-{self.seq}'
        self.parts.append(f'<text id="{ident}" x="{x}" y="{y}" text-anchor="{anchor}" '
                          f'font-family="Liberation Sans, Arial, Helvetica, sans-serif" '
                          f'font-size="{size}" font-weight="{weight}" fill="{self.c.get(color, color)}">'
                          f'{escape(value)}</text>')
        if bounds:
            self.text_boxes.append((ident, bounds))

    def edge(self, pts, color="blue", dashed=False, arrow=True, width=2.6):
        d = 'M ' + ' L '.join(f'{x} {y}' for x, y in pts)
        dash = ' stroke-dasharray="9 7"' if dashed else ''
        marker = f' marker-end="url(#arrow-{color})"' if arrow else ''
        self.parts.append(f'<path d="{d}" fill="none" stroke="{self.c[color]}" '
                          f'stroke-width="{width}" stroke-linejoin="round" stroke-linecap="round"{dash}{marker}/>')

    def dot(self, x, y, color="blue"):
        self.parts.append(f'<circle cx="{x}" cy="{y}" r="4" fill="{self.c[color]}"/>')

    def edge_label(self, x, y, value, width, color="muted", bg="bg", size=19):
        self.rect(x-width/2, y-22, width, 30, self.c[bg], radius=7)
        self.text(x, y, value, size, color=color, anchor="middle")

    def node(self, x, y, w, h, title, lines=(), color="blue", dashed=False, title_size=25):
        self.rect(x, y, w, h, self.c[color+"_fill"], self.c[color], dashed=dashed)
        bounds = (x+14, y+10, x+w-14, y+h-9)
        total = 28 + len(lines)*28
        baseline = y + (h-total)/2 + 22
        self.text(x+w/2, baseline, title, title_size, 700, anchor="middle", bounds=bounds)
        for i, line in enumerate(lines):
            self.text(x+w/2, baseline+32+i*28, line, 21, color="muted", anchor="middle", bounds=bounds)

    def section(self, x, y, w, h, number, title, color="blue"):
        self.rect(x, y, w, h, self.c["panel"], self.c["border"], radius=22)
        self.rect(x+24, y+20, 38, 32, self.c[color+"_fill"], radius=9)
        self.text(x+43, y+43, number, 18, 700, color, "middle")
        self.text(x+78, y+44, title, 24, 700)

    def save(self, path):
        path.write_text('\n'.join(self.parts + ['</svg>'])+'\n', encoding='utf-8')


def architecture(theme):
    s = SVG(1520, 1590, theme, "DINOIDOL architecture",
            "Conceptual DINO and MaskDINO-style frame segmentation with IDOL temporal association. "
            "Encoded features supply reference boxes, decoder memory, and pixel features. "
            "Training-only denoising queries enter the decoder separately. Class, box, mask, "
            "and re-identification predictions are associated into persistent video tracks.")
    s.text(48, 45, "DINOIDOL  /  CONCEPTUAL ARCHITECTURE", 18, 700, "blue")
    s.text(48, 94, "From video frames to tracked instruments", 40, 700)
    s.text(48, 132, "DINO / MaskDINO-style frame segmentation with IDOL temporal association", 24, color="muted")
    for x, label, col, dashed in [(48, "Forward pass", "blue", False),
                                 (355, "Training only", "amber", True),
                                 (670, "Temporal association", "teal", False)]:
        s.edge([(x, 174), (x+50, 174)], col, dashed)
        s.text(x+64, 181, label, 20, color="muted")

    # Section backgrounds precede all routes so arrows stay visible.
    s.section(40, 210, 1440, 240, "01", "Encode each frame")
    s.section(40, 510, 1008, 418, "02", "Initialize and refine object queries")
    s.section(40, 964, 1440, 240, "03", "Predict each instance")
    s.section(40, 1260, 1440, 242, "04", "Associate instances across time", "teal")

    # Frame encoder: a deliberately aggregated feature-processing block.
    s.node(64, 285, 280, 118, "Video frames", ["t − 1  ·  t  ·  t + 1", "one frame at a time"])
    s.node(408, 285, 288, 118, "Backbone", ["CNN / ViT", "multi-scale feature maps"])
    s.node(752, 285, 344, 118, "Feature encoder × N", ["tokens + position / level", "multi-scale deformable attention"], title_size=24)
    s.node(1152, 285, 304, 118, "Encoded features", ["visual memory", "+ spatial feature branch"])
    for a, b in [(344, 408), (696, 752), (1096, 1152)]:
        s.edge([(a, 344), (b, 344)])
    s.text(776, 430, "Includes feature fusion for the mask branch.", 18, color="muted")

    # Encoded proposals initialize positions; content queries are learned.
    s.edge([(1224, 403), (1224, 476), (20, 476), (20, 636), (64, 636)])
    s.edge_label(690, 476, "encoder proposals", 190)
    s.node(64, 582, 400, 108, "Top-K query selection", ["initial reference boxes / anchors"])
    s.node(560, 582, 440, 108, "Learnable content queries", ["learned instance query embeddings"])
    s.edge([(264, 690), (264, 720), (610, 720), (610, 748)])
    s.edge_label(424, 720, "position", 88, bg="panel")
    s.edge([(850, 690), (850, 748)])
    s.edge_label(894, 725, "content", 86, bg="panel")

    # The memory and high-resolution mask features share an upstream feature bundle.
    s.edge([(1304, 403), (1304, 748)])
    s.edge([(1304, 724), (1032, 724), (1032, 784), (1000, 784)])
    s.dot(1304, 724)
    s.edge_label(1190, 724, "key / value memory", 214)
    s.node(1132, 748, 324, 138, "Pixel feature map", ["high-resolution embeddings", "encoder + backbone fusion"], title_size=24)
    s.node(560, 748, 440, 138, "Transformer decoder × M",
           ["self-attention + cross-attention", "iterative query / box refinement"], title_size=24)

    # Auxiliary branch: never part of the inference path.
    s.node(64, 770, 400, 116, "Contrastive denoising (CDN)",
           ["ground truth + noise → aux. queries", "training only"], "amber", True, 23)
    s.edge([(464, 828), (560, 828)], "amber", dashed=True)

    # Query features fan out to three distinct heads. Pixel features are an
    # independent input to the mask head, never an output of that head.
    s.edge([(780, 886), (780, 1022)], arrow=False)
    s.edge_label(780, 948, "refined instance queries", 256)
    s.edge([(238, 1040), (238, 1022), (1208, 1022)], arrow=False)
    for x in (238, 780, 1208):
        s.edge([(x, 1022), (x, 1040)])
    s.dot(780, 1022)
    s.edge([(1304, 886), (1304, 1040)])
    s.edge_label(1304, 941, "pixel embeddings", 190)
    s.node(64, 1040, 348, 118, "Class + box heads", ["class logits / confidence", "bounding boxes"])
    s.node(560, 1040, 440, 118, "Re-ID embedding head", ["instance appearance vectors", "for temporal association"], "teal")
    s.node(1108, 1040, 348, 118, "Mask head", ["query mask embeddings", "× pixel map → instance masks"])

    # The bus represents packing outputs from the same queries, not summation.
    for x in (238, 780, 1282):
        s.edge([(x, 1158), (x, 1228)], arrow=False)
    s.edge([(20, 1228), (1282, 1228)], arrow=False)
    s.edge([(20, 1228), (20, 1393), (64, 1393)])
    for x in (238, 780):
        s.dot(x, 1228)
    s.edge_label(780, 1228, "per-frame prediction bundle", 300)

    s.node(64, 1334, 400, 118, "Frame instances", ["label  ·  box  ·  mask", "+ Re-ID embedding"], "teal")
    s.node(560, 1334, 440, 118, "IDOL online association", ["match against track history", "assign IDs + update track memory"], "teal")
    s.node(1108, 1334, 348, 118, "Video instances", ["persistent track IDs", "classes + masks over time"], "teal")
    s.edge([(464, 1393), (560, 1393)], "teal")
    s.edge([(1000, 1393), (1108, 1393)], "teal")
    s.text(64, 1484, "Track memory is carried forward and updated for each incoming frame.", 20, color="muted")
    s.text(48, 1545, "Conceptual integration based on the supplied schematic; repository implementation is not verified.", 20, color="muted")
    s.text(48, 1572, "N / M, feature scales, query initialization and denoising settings depend on configuration.", 19, color="muted")
    return s


def comparison(theme):
    s = SVG(1440, 1000, theme, "DINOIDOL and CP-SIS: complementary views",
            "Side-by-side conceptual comparison: DINOIDOL links instrument instances over time, "
            "while CP-SIS uses DINOv2 features and class prototypes to classify proposal masks. "
            "Combining prototype-guided classification and IDOL tracking is a future direction "
            "marked unimplemented in the supplied repository schematic.")
    s.text(48, 45, "SURGICAL INSTRUMENT SEGMENTATION", 18, 700, "blue")
    s.text(48, 94, "Two complementary views", 40, 700)
    s.text(48, 132, "Temporal identity across video  ·  Class discrimination within each frame", 24, color="muted")

    for x, title, sub, color in [(40, "DINOIDOL", "VIDEO INSTANCE SEGMENTATION", "blue"),
                                 (740, "CP-SIS", "CLASS-AWARE FRAME SEGMENTATION", "pink")]:
        s.rect(x, 180, 660, 600, s.c["panel"], s.c["border"], radius=22)
        s.rect(x+24, 204, 6, 64, s.c[color], radius=3)
        s.text(x+48, 231, title, 30, 700)
        s.text(x+48, 262, sub, 18, 700, "muted")

    left = [
        (300, "MaskDINO frame predictions", ["Object queries, boxes and instance masks"]),
        (452, "IDOL online association", ["Re-ID embeddings + track memory"]),
        (604, "Tracked instruments", ["Mask sequences + persistent instance IDs"]),
    ]
    right = [
        (300, "DINOv2 features + LoRA", ["Visual features from proposal-defined ROIs"]),
        (452, "Learnable class prototypes", ["Prototype-guided class discrimination"]),
        (604, "Class-aware masks", ["Class assignments for the proposal masks"]),
    ]
    for x, nodes, color in [(72, left, "blue"), (772, right, "pink")]:
        for y, title, lines in nodes:
            s.node(x, y, 596, 108, title, lines, color, title_size=25)
        for y in (408, 560):
            s.edge([(x+298, y), (x+298, y+44)], color)
    s.text(72, 752, "Focus: frame-to-frame identity and mask continuity.", 21, color="muted")
    s.text(772, 752, "Focus: class separation with efficient adaptation.", 21, color="muted")

    # Dotted links explicitly encode a proposal, not an implemented bridge.
    s.edge([(370, 780), (370, 820), (530, 820), (530, 846)], "amber", True)
    s.edge([(1070, 780), (1070, 820), (910, 820), (910, 846)], "amber", True)
    s.node(288, 846, 864, 100, "Future integration · NOT IMPLEMENTED",
           ["Prototype-guided classification + IDOL temporal tracking"], "amber", True, 25)
    s.text(48, 981, "DINO / MaskDINO detection models and the DINOv2 feature backbone are distinct model families.",
           20, color="muted")
    return s


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", type=Path, default=Path(__file__).resolve().parents[1]/"assets")
    p.add_argument("--png", action="store_true", help="Also export 2x PNGs using Inkscape")
    p.add_argument("--theme", choices=["all", *THEMES], default="all")
    args = p.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    if args.png and not shutil.which("inkscape"):
        p.error("PNG export requires Inkscape on PATH. SVG generation needs only Python.")
    themes = list(THEMES) if args.theme == "all" else [args.theme]
    for stem, build in [("dinoidol_architecture", architecture), ("dinoidol_cpsis_comparison", comparison)]:
        for theme in themes:
            drawing = build(theme)
            svg = args.out/f"{stem}_{theme}.svg"
            drawing.save(svg)
            print(svg)
            if args.png:
                png = svg.with_suffix('.png')
                subprocess.run(["inkscape", str(svg), "--export-type=png", f"--export-width={drawing.w*2}",
                                f"--export-filename={png}"], check=True, capture_output=True)
                print(png)


if __name__ == "__main__":
    main()
